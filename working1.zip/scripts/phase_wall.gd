extends StaticBody3D

# Phase wall — exists only in one world (real or spirit)
# In the other world it becomes invisible and non-collidable
# Name nodes with "Wall" prefix so the spiral shader treats them as structural

@export var phase: String = "real"  # "real" or "spirit"
@export var wall_size: Vector3 = Vector3(0.25, 3.0, 1.75)

var _last_spirit: bool = false
var _initialized: bool = false

func _ready():
	collision_layer = 1
	collision_mask = 0

	# Create mesh
	var mesh_inst = MeshInstance3D.new()
	var box_mesh = BoxMesh.new()
	box_mesh.size = wall_size
	var mat = StandardMaterial3D.new()
	if phase == "real":
		mat.albedo_color = Color(0.68, 0.65, 0.72, 1)
	else:
		mat.albedo_color = Color(0.55, 0.48, 0.7, 1)
	box_mesh.material = mat
	mesh_inst.mesh = box_mesh
	mesh_inst.name = "Mesh"
	add_child(mesh_inst)

	# Create collision
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = wall_size
	col.shape = shape
	col.name = "Col"
	add_child(col)

	# Initial state
	_update_phase(false)

func _process(_delta):
	# Phase walk must be unlocked before walls toggle
	var gm = get_node_or_null("/root/GameManager")
	if gm and not gm.phase_walk_unlocked:
		# Ability not unlocked — wall always exists (solid)
		if not _initialized:
			_initialized = true
			_force_solid()
		return

	var player = _find_player()
	if not player:
		return
	var is_spirit = player.spirit_world if "spirit_world" in player else false
	if is_spirit != _last_spirit or not _initialized:
		_last_spirit = is_spirit
		_initialized = true
		_update_phase(is_spirit)

func _update_phase(is_spirit: bool):
	var should_exist = (phase == "real" and not is_spirit) or (phase == "spirit" and is_spirit)
	visible = should_exist
	collision_layer = 1 if should_exist else 0
	for child in get_children():
		if child is CollisionShape3D:
			child.disabled = not should_exist

func _force_solid():
	visible = true
	collision_layer = 1
	for child in get_children():
		if child is CollisionShape3D:
			child.disabled = false

func _find_player() -> Node:
	var p = get_node_or_null("../Player")
	if p:
		return p
	# Fallback: search scene root
	var root = get_tree().current_scene
	if root:
		return root.get_node_or_null("Player")
	return null
