extends Area3D

# Pressure plate — activates when a player or pushable block stands on it
# Notifies target via plate_activated() / plate_deactivated()

@export var target_path: NodePath = ""
@export var plate_size: Vector3 = Vector3(1.2, 0.05, 1.2)

var bodies_on: int = 0
var is_active: bool = false
var plate_mat: StandardMaterial3D

func _ready():
	collision_layer = 0
	collision_mask = 10  # player (2) + pushable (8)

	# Visual plate (flat slab on the floor)
	var mesh_inst = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = plate_size
	plate_mat = StandardMaterial3D.new()
	plate_mat.albedo_color = Color(0.3, 0.3, 0.5)
	box.material = plate_mat
	mesh_inst.mesh = box
	mesh_inst.name = "PlateMesh"
	add_child(mesh_inst)

	# Detection shape — taller than the visual so bodies standing on it register
	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(plate_size.x, 0.6, plate_size.z)
	col.shape = shape
	col.position.y = 0.3
	col.name = "Col"
	add_child(col)

	body_entered.connect(_on_enter)
	body_exited.connect(_on_exit)

func _on_enter(body):
	if (body.collision_layer & 2) != 0 or (body.collision_layer & 8) != 0:
		bodies_on += 1
		_update_state()

func _on_exit(body):
	if (body.collision_layer & 2) != 0 or (body.collision_layer & 8) != 0:
		bodies_on = max(bodies_on - 1, 0)
		_update_state()

func _update_state():
	var now_active = bodies_on > 0
	if now_active == is_active:
		return
	is_active = now_active

	# Visual feedback
	if is_active:
		plate_mat.albedo_color = Color(0.2, 0.6, 0.3)
		plate_mat.emission_enabled = true
		plate_mat.emission = Color(0.1, 0.4, 0.15)
		plate_mat.emission_energy_multiplier = 0.5
	else:
		plate_mat.albedo_color = Color(0.3, 0.3, 0.5)
		plate_mat.emission_enabled = false

	# Notify target
	var target = get_node_or_null(target_path)
	if target:
		if is_active and target.has_method("plate_activated"):
			target.plate_activated()
		elif not is_active and target.has_method("plate_deactivated"):
			target.plate_deactivated()
